﻿<!DOCTYPE html>

<html lang="en">
<?php include_once('includes/header.php') ?>

  <div id="wrapper">

  <!-- Hero
  ================================================== -->
    <section>
      <div id="hero-section" class="home-hero" data-stellar-background-ratio="0">
        <div class="hero-content">
          <div class="container">
            <div class="row">
              <div class="col-sm-8 col-sm-offset-2">

                <div class="hero-text">
                  <div class="herolider">
                    <ul class="caption-slides">

                      <li class="caption">
                        <h1>Welcome To GasNow Wallet</h1>
                        <div class="div-line"></div>
                        
                      </li>

                    </ul>
                  </div> <!-- end herolider -->
                </div> <!-- end hero-text -->

                <div class="hero-btn">
                  <a href="form/signup.php" class="btn btn-lg btn-primary">SignUp</a>
                </div> <!-- end hero-btn -->

              </div> <!-- end col-md-6 -->
            </div> <!-- end row -->
          </div> <!-- End container -->
        </div> <!-- End hero-content -->
      </div> <!-- End hero-section -->
    </section>
    <!-- End hero section -->

    <!-- Offer
    ================================================== -->
    <section>
      <div id="landing-offer" class="pad-sec">
        <div class="container">

          <div class="title-section big-title-sec animated out" data-animation="fadeInUp" data-delay="0">
            <div class="row">
              <div class="col-sm-8 col-sm-offset-2">
                <h2 class="big-title">Introduction</h2>
                <h1 class="big-subtitle">Gasnow wallet is a fin-tech startup that is digitizing access to LPG clean cooking
                         and CNG autogas in Nigeria and Africa.</h1>
                <hr>
                <p class="about-text"><b>Our goal is to serve Nigeria and sub-sahara Africa emerging markets who spend 7.5% of their
                      annual income, about $7 billion on dirty fuel like charcoal, firewood, eliminate indoor air pollution
                    (a major cause of 4million annual death) contribute to net zero emission and SDG 7(Access to clean energy for all)</b></p>
              </div>
            </div> <!-- End row -->
          </div> <!-- end title-section -->

          <div class="offer-boxes">

            <div class="row">
            <div class="col-sm-4">
              <div class="offer-post text-center animated out" data-animation="fadeInLeft" data-delay="0">
                <div class="offer-icon">
                  <span class="icon-desktop"></span>
                </div>
                <h4>Our Target</h4>
                <p>Through our growing network, we serve urban and last mile market demography...</p>
              </div> <!-- End offer-post -->
            </div> <!-- End col-sm-4 -->

            <div class="col-sm-4">
              <div class="offer-post text-center animated out" data-animation="fadeInUp" data-delay="0">
                <div class="offer-icon">
                  <span class="icon-piechart"></span>
                </div>
                <h4>Our Goal</h4>
                <p>Our goal is to serve Nigeria and sub-sahara Africa emerging markets who spend 7.5% of their
                      annual income, about $7 billion on dirty fuel like charcoal, firewood, eliminate indoor air pollution
                    (a major cause of 4million annual death) contribute to net zero emission and SDG 7(Access to clean energy for all)</p>
              </div> <!-- End offer-post -->
            </div> <!-- End col-sm-4 -->

            <div class="col-sm-4">
              <div class="offer-post text-center animated out" data-animation="fadeInRight" data-delay="0">
                <div class="offer-icon">
                  <span class="icon-lifesaver"></span>
                </div>
                <h4>Problem statement</h4>
                <p>35million household in Nigeria do not have access to clean cooking and 
                          750million household in Sub-sahara Africa spend 7.5% of the income about $7billion on dirty fuel.</p>
              </div> <!-- End offer-post -->
            </div> <!-- End col-sm-4 -->

            </div> <!-- End row -->

          </div> <!-- End offer-boxes -->
        </div> <!-- End container -->
      </div> <!-- End landing-offer-section -->
    </section>
    <!-- End offer section -->

    <section>
      <div class="sep-section"></div>
    </section>

    

    
   
    <!-- Banner-Services
    ================================================== -->
    <section>
      <div id="banner-services" data-stellar-background-ratio="0">
        <div class="container">
          <div class="row">

            <div class="col-sm-6">
              <div class="banner-content animated out" data-animation="fadeInUp" data-delay="0">
                <h3 class="banner-heading">Our Target?</h3>
                <div class="banner-decription">
                  Through our growing network, We serve urban and last mile market demography.
                </div> <!-- end banner-decription -->
                <div>
                  <a href="form/signup.php" class="btn btn-lg btn-primary">Sign Up</a>
                </div>
              </div> <!-- end banner-content -->
            </div> <!-- end col-sm-6 -->

            <div class="col-sm-6">
              <div class="banner-image animated out" data-animation="fadeInUp" data-delay="0">
                <img src="assets/images/t4.jpg" alt="">
              </div> <!-- end banner-image -->
            </div> <!-- end col-sm-6 -->
            
          </div> <!-- end row -->
        </div> <!-- end container -->
      </div>
    </section>

<!-- Partnership
    ================================================== -->
    <section>
      <div id="team-section" class="pad-sec">
        <div class="container">
          <div class="title-section animated out" data-animation="fadeInUp" data-delay="0">
            <div class="row">
              <div class="col-sm-8 col-sm-offset-2">
                <h2>Partnership</h2>
                <hr>
                
              </div>
            </div> <!-- End row -->
          </div> <!-- end title-section -->

          <div class="team-members">
            <div class="row">

             
              <div class="col-sm-4">
               
                  <img src="assets/images/partners/baxi.jpeg" alt="" height="">
                  
                  
                
              </div> <!-- End col-sm-4 -->

              
              <div class="col-sm-4">
                
                  <img src="assets/images/partners/fsi.jpeg" alt="" height="">
                  
               
              </div> <!-- End col-sm-4 -->

              
              <div class="col-sm-4">
                
                  <img src="assets/images/partners/nnpc.jpeg" alt="" height="">
                  
                
              </div> <!-- End col-sm-4 -->

              
              <div class="col-sm-4">
                
                  <img src="assets/images/partners/zen.jpeg" alt="" height="">
                  
                
              </div> <!-- End col-sm-4 -->

              
              <div class="col-sm-4">
                
                  <img src="assets/images/" alt="" height="">
                  
                    
              </div> <!-- End col-sm-4 -->
             
              <div class="col-sm-4">
                
                  <img src="assets/images/" alt="" height="">
                  
                
              </div> <!-- End col-sm-4 -->

            </div>
          </div> <!-- End Partnership -->
        </div> <!-- End container -->
      </div> <!-- End partner-section -->
    </section>
    <!-- End partner section -->
    
    <!-- Creative section-1
    ================================================== -->
    <section>
      <div id="creative-section-1" class="pad-sec">
        <div class="container">
          <div class="row">

            <div class="col-sm-7 img-creative-left text-center animated out" data-animation="fadeInLeft" data-delay="0">
              <figure>
                <img src="assets/images/p1.jpeg" alt="">
              </figure>
            </div> <!-- End col-sm-8 -->

            <div class="col-sm-5 creative-content-right animated out" data-animation="fadeInRight" data-delay="0">

                <p>Do you want to be a Gaspreneur merchant?, Delivery Agent?, Commercial LPG user?,
                  LPG end user?, LPG station?.</p>

              <div class="view-more">
                <a href="form/signup.php" class="btn btn-lg btn-primary">Sign Up</a>
              </div>
            </div> <!-- End feature-content -->

          </div> <!-- End row -->
        </div> <!-- End container -->
      </div> <!-- End feature-section -->
    </section>
    <!-- End Creative section-1 -->

    <section>
      <div class="sep-section"></div>
    </section>

<?php include_once('includes/footer.php') ?>

    
   
    
</html>