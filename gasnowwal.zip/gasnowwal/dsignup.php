<!doctype html>
<html lang="en">
  

<?php include_once('includes/header.php') ?>
  

  <div class="content">
    
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-10">
          

          <div class="row justify-content-center">
            <div class="col-md-6">
              
              <h3 class="heading mb-4">GasNow wallet Delivery Agent</h3>
              <p>Create a Gasnow wallet Delivery Agent account</p>

              <p><img src="images/agent.jpeg" alt="Image" class="img-fluid"></p>


            </div>
            
            <?php include_once('includes/signup.php') ?>


          </div>
        </div>
      </div>
    </div>

  </div>
    
    

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/main.js"></script>

  </body>
</html>