<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Gasnow wallet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Favicon -->
  <link rel="icon" href="assets/images/logo.jpg">

    <title>GasNow Wallet</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="sets/css/fontawesome.css">
    <link rel="stylesheet" href="sets/css/templatemo-finance-business.css">
    <link rel="stylesheet" href="sets/css/owl.css">

  </head>

  <body>

  <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  

   

    <!-- Page Content -->
    

    

    <div class="services">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2>Let's get <em>Started</em></h2>
              
            </div>
          </div>
          <div class="col-md-4">
            <div class="service-item">
              <div class="down-content">
                <h4>Gaspreneur Merchant?</h4>
                
                <a href="form/msignup.php" class="filled-button">Sign Up</a>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="service-item">
              <div class="down-content">
                <h4>Delivery Agent?</h4>
                <a href="form/dsignup.php" class="filled-button">Sign Up</a>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="service-item">
              <div class="down-content">
                <h4>Commercial LPG user?(Restaurant, hotel)</h4>
                
                <a href="form/csignup.php" class="filled-button">Sign Up</a>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="service-item">
              <div class="down-content">
                <h4>LPG end user?</h4>
                
                <a href="form/usignup.php" class="filled-button">Sign Up</a>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="service-item">
              <div class="down-content">
                <h4>LPG Station?</h4>
                <a href="form/lsignup.php" class="filled-button">Sign Up</a>
              </div>
            </div>
          </div>
          <br>
          <div class="col-md-4">
            <div class="service-item">
              <div class="down-content">
                <h4>Collect new cylinder/Swap Old cylinder?</h4>
                <a href="form/swap.php" class="filled-button">Sign Up</a>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </div>
<br>
<br>
  <center>  
 <a href="index.php">Back to home </a>

</center>
    

    
      
    

    


    
    
    

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Additional Scripts -->
    <script src="sets/js/custom.js"></script>
    <script src="sets/js/owl.js"></script>
    <script src="sets/js/slick.js"></script>
    <script src="sets/js/accordions.js"></script>

    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>

  </body>
</html>